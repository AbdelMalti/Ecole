package probleme1;

import java.util.Random;
import java.util.ArrayList;

public class LinearSpacePerfectHashing<AnyType>
{
	static int p = 46337;

	QuadraticSpacePerfectHashing<AnyType>[] data;
	int a, b;

	LinearSpacePerfectHashing()
	{
		a=b=0; data = null;
	}

	LinearSpacePerfectHashing(ArrayList<AnyType> array)
	{
		AllocateMemory(array);
	}

	public void SetArray(ArrayList<AnyType> array)
	{
		AllocateMemory(array);
	}

	/*
     * Description : Fonction qui remplit la table avec un hashage parfait (utilisant des listes chainees)
     * @param: (ArrayList<AnyType>) Array contenant tous les elements qu'il faut ajouter a la table
     * return: void
     */
	@SuppressWarnings("unchecked")
	private void AllocateMemory(ArrayList<AnyType> array)
	{
		Random generator = new Random( System.nanoTime() );

		// Tout mettre a null si le array est vide
		if(array == null || array.size() == 0)
		{
			a=b=0;
			data=null;
			return;
		}
		// Si le array ne contient qu'un seul element, il suffit de l'ajouter directement a la table
		if(array.size() == 1)
		{
			a = b = 0;
			data = new QuadraticSpacePerfectHashing[1];
			data[0].SetArray(array);
			return;
		}
		// Si le array contient plus qu'un element, il faut placer correctement tous les elements
		
		// Generer les valeurs de a et de b
		a=generator.nextInt(p - 1) + 1; // a doit etre strictement plus grand que 0
		b=generator.nextInt(p);
		
		int index = 0; // Index dans la table de Hashage
		int tailleQuadratic = 0; // Utilisee pour la taille de chaque quadratic a l'interieur de la boucle for
		
		// Determiner la taille m de data qui correcpond au nombre d'elements dans le array
		int m = array.size();
		
		// Creer un array temporaire
		ArrayList<AnyType> nouveauArray = new ArrayList<AnyType>();

		// Creer toutes les quadratic necessaires
		data = new QuadraticSpacePerfectHashing[m];
		for(int i = 0; i < m ; i++) { 
			data[i] = new QuadraticSpacePerfectHashing<AnyType>(); 
		}
		
		for (int i = 0; i < m ; i++ ) {
			// Calculer l'index du nouvel element 
			index = ((a*array.get(i).hashCode()+b)%p)%m; 
			
			// Vider le array temporaire 
			nouveauArray.clear(); 
			
			// Si data[index] est vide, c'est qu'il n'y eu aucune collision 
			// Et qu'on peut tout simplement ajouter l'element courant 
			if (data[index].Size() == 0){ 
				nouveauArray.add(array.get(i)); 
			} else { // Sinon, il faut aller recuperer les autres elements avant d'ajouter le nouveau 
				tailleQuadratic = data[index].Size();
				for (int j = 0 ; j < tailleQuadratic; j++){
					if (data[index].items[j] != null ) {
						nouveauArray.add(data[index].items[j]); 
					}
				}
				// Ajouter aussi le nouvel element
				nouveauArray.add(array.get(i)); 
			} 
			// Remplir la quadratic avec le array 
			data[index].SetArray(nouveauArray);
		}
		
	}

	public int Size()
	{
		if( data == null ) return 0;

		int size = 0;
		for(int i=0; i<data.length; ++i)
		{
			size += (data[i] == null ? 1 : data[i].Size());
		}
		return size;
	}

	/*
     * Description : Fonction qui verifie si l'element est present dans la table
     * @param: (AnyType) element que l'on cherche
     * return: (boolean) true si l'element est present dans la table
     */
	public boolean contains(AnyType x )
	{	   
		// Calculer la taille de la table de hashage
		int m = data.length;
		// Calculer l'index de l'element
		int index=((a*x.hashCode()+b)%p)%m;
		// Si l'index est vide, retourner false
		if (data[index] == null){
			return false;
		}
		// Sinon, chercher l'element dans la quadratique
		return data[index].contains( x );
	}
	
	/*
     * Description : Fonction qui retourne un element s'il est present dans la table
     * @param: (AnyType) element que l'on desire selectionner
     * return: (AnyType) l'element a selectionner (ou null s'il n'est pas dans la table)
     */
	public AnyType getItem (AnyType x) {
		// Calculer la taille de la table de hashage
		int m = data.length;
		// Calculer l'index de l'element
		int index=((a*x.hashCode()+b)%p)%m;	
		// Si l'index est vide, retourner null
		if (data[index] == null){
			return null;
		}
		// Sinon chercher l'element dans la quadratique
		return data[index].getItem(x);	
	}
	
	/*
     * Description : Fonction qui elimine un element s'il est present dans la table
     * @param: (AnyType) element que l'on desire eliminer
     * return: void
     */
	public void remove (AnyType x) {
		// Calculer la taille de la table de hashage
		int m = data.length;
		// Calculer l'index de l'element
		int index=((a*x.hashCode()+b)%p)%m;
		// Si l'index est vide, sortir de la fonction
		if (data[index] == null){
			return;
		}
		// Sinon, retirer l'element de la quadratique
		data[index].remove( x );
	}
}
