package probleme1;

import java.util.ArrayList;
import java.util.Random;

public class QuadraticSpacePerfectHashing<AnyType> 
{
	static int p = 46337;

	int a, b;
	AnyType[] items;

	QuadraticSpacePerfectHashing()
	{
		a=b=0; items = null;
	}

	QuadraticSpacePerfectHashing(ArrayList<AnyType> array)
	{
		AllocateMemory(array);
	}

	public void SetArray(ArrayList<AnyType> array)
	{
		AllocateMemory(array);
	}

	public int Size()
	{
		if( items == null ) return 0;

		return items.length;
	}

	 /*
     * Description : Fonction qui verifie si l'element est present dans la table
     * @param: (AnyType) element que l'on cherche
     * return: (boolean) true si l'element est present dans la table
     */
	public boolean contains(AnyType x )
	{
		// Verifier si la table est vide
		  if( items == null ) {
			  return false;
		  }
			 
		  int index = 0; // Index de l'element dans la table de Hashage
		  int m = items.length; // Taille de la table de Hashage
		  
	      if( a != 0 ) { // Si a n'est pas nul, calculer l'index (car ce dernier ne sera pas nul)
	    	index = ((a*x.hashCode()+b)%p)%m;  
	      }
	      
	      // Retourner true si l'element se trouve bel et bien a l'index trouve
	      return  x.equals(items[index]);
	}

	/*
     * Description : Fonction qui retourne un element s'il est present dans la table
     * @param: (AnyType) element que l'on desire selectionner
     * return: (AnyType) l'element a selectionner (ou null s'il n'est pas dans la table)
     */
	public AnyType getItem (AnyType x) {
		
		// Verifier si l'element se trouve dans la table 
		if(this.contains(x)){
			int m = items.length;
		    int index = ((a*x.hashCode()+b)%p)%m;
		    
		    return items[index];
		} else {
			return null;
		}
	

	}

	/*
     * Description : Fonction qui elimine un element s'il est present dans la table
     * @param: (AnyType) element que l'on desire eliminer
     * return: void
     */
	public void remove (AnyType x) {
		
		if(this.contains(x)){
			int m = items.length;
		    int index = ((a*x.hashCode()+b)%p)%m;
		     items[index]=null;
		}
	}

	/*
     * Description : Fonction qui remplit la table de hashage en evitant toute collision
     * @param: (ArrayList<AnyType>) Array contenant tous les elements qu'il faut ajouter a la table
     * return: void
     */
	@SuppressWarnings("unchecked")
	private void AllocateMemory(ArrayList<AnyType> array)
	{
		Random generator = new Random( System.nanoTime() );

		// Tout mettre a null si le array est vide
		if(array == null || array.size() == 0)
		{
			a = b = 0;
			items=null;
			return;
		}
		// Si le array ne contient qu'un seul element, il suffit d'ajouter ce dernier a items
		if(array.size() == 1)
		{
			a = b = 0;
			items = (AnyType[]) new Object[1];
			items[0]=array.get(0);
			return;
		}
		
		// Si la array contient plus qu'un element, il faut bien les placer dans la table de hashage
		int m = 0;	// Taille de la table de Hashage
		int index = 0 ;	// Index de la table de Hashage
		do
		{
			// Vider items
			items = null;

			// Generer a et b aleatoirement en nous assurant qu'ils ne depassent pas p
			a=generator.nextInt(p - 1) + 1; // a doit etre strictemen
			b=generator.nextInt(p);
			
			// Table de Hashage dont la taille est proportionnelle au carre du nombre d'elements
			m = array.size()*array.size();
			items = (AnyType[]) new Object[m];
			
			// Placer chaque element dans son index correspondant
			for(int i=0;i<array.size();i++){
				index = ((a*array.get(i).hashCode()+b)%p)%m; 
				items[index]= array.get(i);
			}	
		}
		while( collisionExists( array ) ); // Repeter la sequence jusqu'a ce qu'il n'y ait plus du tout de collisions
	}

	/*
     * Description : Fonction qui verifie si la table contient des collisions
     * @param: (ArrayList<AnyType>) Array contenant tous les elements qui avaient ete ajoutes a la table
     * return: (boolean) true s'il y a au moins une collision, false sinon
     */
	@SuppressWarnings("unchecked")
	private boolean collisionExists(ArrayList<AnyType> array)
	{
		int compteur = 0; // Compteur d'elements non null dans items
		for (int i = 0 ; i < items.length ; i++ ) {
			if (items[i] != null){
				compteur++;
			}
		}
		// S'il n'y a eu aucune collision, items contient le meme nombre d'elements que array
		if (compteur == array.size()){
			return true;
		} else {
			// Sinon, 1 ou plus element(s) a(ont) ete ecrase(s) et donc il y a eu collision
			return false;
		}
	
	}
}
