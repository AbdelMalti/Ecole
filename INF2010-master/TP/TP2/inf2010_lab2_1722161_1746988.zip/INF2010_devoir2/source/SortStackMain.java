import java.util.Random;
import java.util.Stack;


public class SortStackMain 
{
	static final int COUNT = 30;
	static final int MAX_VALUE = 1000;
	
	public static void main(String[] args) 
	{
		boolean sortIsGood = true;
		
		Random generator = new Random( System.nanoTime() );
		Stack<Integer> stack = new Stack<Integer>();
		
		for(int i = 0; i < COUNT; i++)
			stack.push(generator.nextInt(MAX_VALUE));
		stack = sortStack(stack);
		
		boolean countIsGood = size(stack) == COUNT;
			
		int tmp = stack.pop();
		while(!stack.isEmpty())
		{
			System.out.print(tmp + ", ");
			
			if(tmp > stack.peek())
				sortIsGood = false;
			
			tmp = stack.pop();
		}
		System.out.println(tmp);
		
		if(!countIsGood)
			System.out.println("Erreur: il manque des elements dans la pile");
		else if(!sortIsGood)
			System.out.println("Erreur: le trie a echoue");
		else
			System.out.println("It's all good");
	}
    
	private static int size(Stack<Integer> stack) {
		//A completer
		return stack.size();
    }
    
	static Stack<Integer> sortStack(Stack<Integer> stack)
	{
		//A completer
		/**
		 * Avec 2 stack (stack et temp)
		 */
		Stack<Integer> temp = new Stack<Integer>();
		int element;
		//A Completer
		//Tant que la stack n'a pas �t� vid� de ces �l�ments, on reste dans la boucle.
		while(!stack.empty()){
			//si temp est vide on le rempli
			if(temp.empty()){
				temp.push(stack.peek());
				stack.pop();
			}
			//si un l'�l�ment cible dans stack est plus petit que l'�l�ment cible dans temp, on le rajoute sans probleme
			else if(temp.peek() > stack.peek()){
				temp.push( stack.peek());
				stack.pop();
			}
			//si un l'�l�ment cible dans stack est plus grand que l'�l�ment cible dans temp, on doit s'arranger pour le mettre en ordre croissant
			else if(temp.peek() < stack.peek()){
				element = stack.peek();
				stack.pop();
				//Boucle infinie de laquelle on va sortir seulement avec un break. 
				while(true){
					//si le temp est vide ou que l'�l�ment cible suivant dans le temp est sup�rieur � element, on le rajoute dans temp. 
					if(temp.empty() || (temp.peek() > element)){
						temp.push(element);
						//on change la valeur element afin d'�viter certaine complication... et ce n'Est pas 42...
						element =-1;
						//sortie de la boucle infinie
						break;
					}
					//sinon, on va prendre les valeurs de temp et les sauvegarder dans stack. Ces valeurs seront supprim�es de temp
					else{
						stack.push(temp.peek());
						temp.pop();
					}
				}
			}
		}
		return temp;
	}
}
